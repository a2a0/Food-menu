package com.example.foodmenu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button chek=(Button) findViewById(R.id.button);
        TextView textView=(TextView)findViewById(R.id.textView);
        EditText EditText =(EditText)findViewById(R.id.Edit);
        TextView textView4=(TextView)findViewById(R.id.textView4);
        RadioButton Pizza=(RadioButton)findViewById(R.id.Pizza);
        RadioButton Burger=(RadioButton)findViewById(R.id.Burger);
        RadioButton Spagitti=(RadioButton)findViewById(R.id.Spagitti);
        RadioButton Salad=(RadioButton)findViewById(R.id.Salad);
        RadioGroup radioGroup=(RadioGroup)findViewById(R.id.radioGroup);
        CheckBox ExtraCheese=(CheckBox)findViewById(R.id.ExtraCheese);
        CheckBox ExtraSpicy=(CheckBox)findViewById(R.id.ExtraSpicy);
        CheckBox SmallSize=(CheckBox)findViewById(R.id.SmallSize);
        CheckBox LargeSize=(CheckBox)findViewById(R.id.LargeSize);
        chek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String masg="pressed";
                int radioID =radioGroup.getCheckedRadioButtonId();
                if (Pizza.getId()== radioID){ masg="Pizza "+masg;
                }
                if (Burger.getId()== radioID){ masg="Burger "+masg;
                }
                if (Spagitti.getId()== radioID){ masg="Spagitti "+masg;
                }
                if (Salad.getId()==radioID){ masg="Salad "+masg;
                }
                if( LargeSize.isChecked()){
                    masg="Large Size "+masg;
                }
                if( ExtraCheese.isChecked()){
                    masg="Extra Cheese "+masg;
                }
                if( ExtraSpicy.isChecked()){
                    masg="Extra Spicy"+masg;
                } if( SmallSize.isChecked()){
                    masg="Small Size "+masg;
                }

                Toast.makeText(getApplicationContext(),masg,Toast.LENGTH_SHORT).show();

            }
        });


    }
}